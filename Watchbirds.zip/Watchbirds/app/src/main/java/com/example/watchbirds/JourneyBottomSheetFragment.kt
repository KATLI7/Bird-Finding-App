package com.example.watchbirds


import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import com.google.android.material.bottomsheet.BottomSheetDialogFragment

class JourneyBottomSheetFragment : BottomSheetDialogFragment() {

    private lateinit var distanceTextView: TextView
    private var distanceInMeters: Int = 0 // This will hold the distance in meters
    private val apiKey = "AIzaSyANdBHanJfWq7O58fzHD4Wwsvc0KLWezug" // Replace with your actual API key

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.botton_sheet_fragment, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        distanceTextView = view.findViewById(R.id.Dist)

        // Simulate fetching distance in meters (replace this with actual API call)
        distanceInMeters = 1000 // For example, set this to the fetched distance in meters

        val startJourneyButton = view.findViewById<Button>(R.id.startJourneyButton)
        val logSightButton = view.findViewById<Button>(R.id.logsight)
        val switch = view.findViewById<Switch>(R.id.switch1)

        // Set initial text for distance in kilometers
        updateDistanceText(switch.isChecked)

        startJourneyButton.setOnClickListener {
            Toast.makeText(requireContext(), "Starting Journey...", Toast.LENGTH_SHORT).show()
            // Here you would call fetchDistance() to get the actual distance
        }

        logSightButton.setOnClickListener {
            val intent = Intent(requireContext(), Observations::class.java)
            startActivity(intent)
            Toast.makeText(requireContext(), "Log sighting button clicked!", Toast.LENGTH_SHORT).show()
        }

        switch.setOnCheckedChangeListener { _, isChecked ->
            updateDistanceText(isChecked) // Update text based on switch state
        }
    }

    private fun updateDistanceText(isInMiles: Boolean) {
        val distanceText = if (isInMiles) {
            // Convert to miles
            val distanceInMiles = distanceInMeters * 0.000621371 // Conversion factor
            String.format("M: %.2f", distanceInMiles)
        } else {
            // Display in kilometers
            val distanceInKm = distanceInMeters / 1000.0 // Convert meters to kilometers
            String.format("KM: %.2f", distanceInKm)
        }
        distanceTextView.text = distanceText // Set the distance text
    }
}
