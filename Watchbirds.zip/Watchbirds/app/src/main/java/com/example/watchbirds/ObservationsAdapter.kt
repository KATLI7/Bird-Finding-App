package com.example.watchbirds



import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class ObservationsAdapter(private var observations: MutableList<Observation>) :
    RecyclerView.Adapter<ObservationsAdapter.ObservationViewHolder>() {

    fun setObservations(newObservations: List<Observation>) {
        observations.clear()
        observations.addAll(newObservations)
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ObservationViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.observation_item, parent, false)
        return ObservationViewHolder(view)
    }

    override fun onBindViewHolder(holder: ObservationViewHolder, position: Int) {
        val observation = observations[position]
        holder.bind(observation)
    }

    override fun getItemCount(): Int = observations.size

    class ObservationViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val birdNameTextView: TextView = itemView.findViewById(R.id.birdNameTextView)
        private val locationTextView: TextView = itemView.findViewById(R.id.locationTextView)
        private val timestampTextView: TextView = itemView.findViewById(R.id.timestampTextView)

        fun bind(observation: Observation) {
            birdNameTextView.text = observation.birdName
            locationTextView.text = observation.location
            timestampTextView.text = observation.timestamp?.toDate().toString() ?: "Unknown Time"
        }
    }
}
