package com.example.watchbirds

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth

class MainActivity : AppCompatActivity() {
    private lateinit var signuptext: TextView
    private lateinit var  LoginButton : Button;
    private lateinit var emailField2 : EditText;
    private lateinit var passwordField2 : EditText;
    private lateinit var auth: FirebaseAuth


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        auth = FirebaseAuth.getInstance()

        signuptext = findViewById(R.id.SignupText)
        LoginButton = findViewById(R.id.LogButton)
        emailField2 = findViewById(R.id.email2)
        passwordField2 = findViewById(R.id.Password2)
        loginiup()

        signup() // Call signup() to set the click listener

    }

    private fun signup() {
        signuptext.setOnClickListener {
            val intent = Intent(this, SignActivity::class.java) // Redirect to SignUp activity
            startActivity(intent)
        }
    }
    private fun loginiup()
    {
        LoginButton.setOnClickListener {
            val email = emailField2.text.toString()
            val password = passwordField2.text.toString()

            auth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(this) { task ->
                    if (task.isSuccessful) {
                        Toast.makeText(this, "Success.", Toast.LENGTH_SHORT).show()
                        val intent = Intent(this, Mapview::class.java)
                        startActivity(intent)
                        finish()
                    } else {
                        // If sign in fails, display a message to the user.
                        Toast.makeText(this, "Authentication failed.", Toast.LENGTH_SHORT).show()
                    }
                }
        }
    }
}
