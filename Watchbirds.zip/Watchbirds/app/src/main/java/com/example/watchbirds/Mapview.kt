package com.example.watchbirds


import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Resources
import android.location.Geocoder
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.ImageView
import android.widget.SearchView
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MapStyleOptions
import com.google.android.gms.maps.model.MarkerOptions
import retrofit2.Call
import java.io.IOException
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory


class Mapview : AppCompatActivity() ,OnMapReadyCallback {
    private var mGoogleMap: GoogleMap? = null
    private lateinit var serchbar: SearchView//search function


    private val retrofit = Retrofit.Builder()//hotspots,interface,api
        // Initialize Retrofit with the base URL
        .baseUrl("https://api.ebird.org/v2/")  // Base URL for eBird API
        .addConverterFactory(GsonConverterFactory.create())  // Gson converter for JSON parsing
        .build()
    private val ebirdApi =
        retrofit.create(EbirdApiService::class.java)// only now can i call this one mxm

    //...
    private lateinit var fusedLocationClient: FusedLocationProviderClient//location
    private val LOCATION_PERMISSION_REQUEST_CODE = 1//required


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_mapview)
        val mapFragment =
            supportFragmentManager.findFragmentById(R.id.mapFragment) as SupportMapFragment
        mapFragment.getMapAsync(this)

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)
        serchbar = findViewById(R.id.serchbar)//that searchbar by the map

        val imageView = findViewById<ImageView>(R.id.IconSetting)
        val imageView3 = findViewById<ImageView>(R.id.imageView3)
        val imageView4 = findViewById<ImageView>(R.id.imageView4)
        checkLocationPermission()

        // Listen for search queries in SearchView
        serchbar.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                if (!query.isNullOrEmpty()) {
                    searchForLocation(query)
                }
                return false
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                // Handle search text change if needed
                return false
            }
        })


// Sets an on ClickListener on the ImageView..for future reference , never use this S*it idea again
        imageView.setOnClickListener {
            // Create an Intent to navigate to MainActivity
            val intent = Intent(this, settings::class.java)
            startActivity(intent)


        }
        imageView3.setOnClickListener {
            val intent = Intent(this, Mapview::class.java)
            startActivity(intent)


        }
        imageView4.setOnClickListener {
            val intent = Intent(this, Collections::class.java)
            startActivity(intent)


        }



    }


    override fun onMapReady(googleMap: GoogleMap) {
        loadHotspots()//my birding hotspots
        mGoogleMap = googleMap
        try {
            val success = mGoogleMap?.setMapStyle(
                MapStyleOptions.loadRawResourceStyle(
                    this, R.raw.snazzy_maps
                )
            )
            if (success == false) {
                Log.e("MapActivity", "O flopile.")
            }
        } catch (e: Resources.NotFoundException) {
            e.printStackTrace()
        }

        val pretoria = LatLng(-25.7479, 28.2293)//central co-ordinates (-25.7479, 28.2293)
        mGoogleMap?.moveCamera(CameraUpdateFactory.newLatLngZoom(pretoria, 12f))
        //because were from pta

        mGoogleMap?.setOnMarkerClickListener { marker ->
            // Create an instance of the bottom sheet fragment
            val journeyBottomSheetFragment = JourneyBottomSheetFragment()

            // Show the fragment
            journeyBottomSheetFragment.show(supportFragmentManager, "JourneyBottomSheetFragment")
            true
        }


    }

    private fun checkLocationPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                LOCATION_PERMISSION_REQUEST_CODE
            )
        } else {
            enableLocation()
        }
    }


    // Enabling location tracking stuff once permission is granted
    private fun enableLocation() {
        if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            mGoogleMap?.isMyLocationEnabled = true

            // Get the last known location and update map
            fusedLocationClient.lastLocation.addOnSuccessListener { location ->
                location?.let {
                    val currentLatLng = LatLng(it.latitude, it.longitude)
                    mGoogleMap?.moveCamera(CameraUpdateFactory.newLatLngZoom(currentLatLng, 15f))
                }
            }
        }
    }


    // Handle permission results
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == LOCATION_PERMISSION_REQUEST_CODE) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                enableLocation()
            }

        }


    }

    // Function to search for a location and move the map
    private fun searchForLocation(location: String) {
        val geocoder = Geocoder(this)
        try {
            val addressList = geocoder.getFromLocationName(location, 1) // Get the first result
            if (addressList != null) {
                if (addressList.isNotEmpty()) {
                    val address = addressList[0]
                    val latLng = LatLng(address.latitude, address.longitude)

                    // Add a marker and move the camera to the location
                    mGoogleMap?.addMarker(
                        MarkerOptions().position(latLng).title(location)
                            .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_ORANGE))
                    )
                    mGoogleMap?.moveCamera(
                        CameraUpdateFactory.newLatLngZoom(
                            latLng,
                            15f
                        )
                    ) // Zoom to the location
                }
            }
        } catch (e: IOException) {
            e.printStackTrace()
            Toast.makeText(this, "Location not found", Toast.LENGTH_SHORT).show()

        }


    }

    private fun loadHotspots() {
        // Define the API call using Retrofit
        val call = ebirdApi.getHotspots(
            "ctu7asm3osmb",   // Your API key
            -25.7479,           // Latitude for Central Africa
            28.2293,          // Longitude for Central Africa
            300              // Distance (in km)
        )

        // Enqueue the call asynchronously
        call.enqueue(object : retrofit2.Callback<List<Hotspot>> {
            override fun onResponse(
                call: Call<List<Hotspot>>,
                response: retrofit2.Response<List<Hotspot>>
            ) {
                if (response.isSuccessful) {
                    // Handle the response (e.g., display markers on the map)
                    val hotspots = response.body()
                    hotspots?.let {
                        // Show Hotspots on the map
                        showHotspotsOnMap(it)
                    }
                }
            }

            override fun onFailure(call: Call<List<Hotspot>>, t: Throwable) {
                TODO("Not yet implemented")
            }


        })
    }
    private fun showHotspotsOnMap(hotspots: List<Hotspot>) {
        // Loop through Hotspots and add markers to the map,but also were going
        hotspots.forEach { hotspot ->
            val location = LatLng(hotspot.lat, hotspot.lng)
            mGoogleMap?.addMarker(MarkerOptions().position(location).title(hotspot.locName))
        }
    }

}



