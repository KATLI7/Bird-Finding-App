package com.example.watchbirds




data class DirectionsResponse(
    val routes: List<Route>
)

data class Route(
    val legs: List<Leg>
)

data class Leg(
    val distance: Distance,
    val duration: Duration,
    val end_address: String,
    val start_address: String
)

data class Distance(
    val text: String,
    val value: Int // Value in meters
)

data class Duration(
    val text: String,
    val value: Int // Value in seconds
)
