package com.example.watchbirds

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.QuerySnapshot

class Collections : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var observationsAdapter: ObservationsAdapter
    private val db = FirebaseFirestore.getInstance()
    private val userId = FirebaseAuth.getInstance().currentUser?.uid

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_collections)

        // Initialize RecyclerView
        recyclerView = findViewById(R.id.recyclerViewObservations)
        recyclerView.layoutManager = LinearLayoutManager(this)
        observationsAdapter = ObservationsAdapter(mutableListOf())
        recyclerView.adapter = observationsAdapter

        // Fetch observations from Firestore
        fetchObservations()
    }

    private fun fetchObservations() {
        userId?.let { userId ->
            db.collection("users").document(userId).collection("observations")
                .get()
                .addOnSuccessListener { snapshot ->
                    val observationsList = snapshot?.toObjects(Observation::class.java)
                    if (!observationsList.isNullOrEmpty()) {
                        observationsAdapter.setObservations(observationsList)
                    } else {
                        Toast.makeText(this, "No observations found", Toast.LENGTH_SHORT).show()
                    }
                }
                .addOnFailureListener { exception ->
                    Toast.makeText(this, "Failed to fetch observations: ${exception.message}", Toast.LENGTH_LONG).show()
                }
        } ?: run {
            Toast.makeText(this, "User not logged in", Toast.LENGTH_SHORT).show()
        }
    }
}
