package com.example.watchbirds

data class Observation(
    val birdName: String = "",
    val location: String = "",
    val timestamp: com.google.firebase.Timestamp? = null // Firebase timestamp for sorting if needed
)
