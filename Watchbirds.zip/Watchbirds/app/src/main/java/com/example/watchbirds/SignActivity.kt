package com.example.watchbirds

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth

class SignActivity : AppCompatActivity() {

    private lateinit var logintext: TextView;
    private lateinit var signUpButton : Button;
    private lateinit var emailField : EditText;
    private lateinit var passwordField : EditText;
    private lateinit var auth: FirebaseAuth


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sign)

        signUpButton = findViewById(R.id.SignButton)
        logintext=findViewById(R.id.SignupText)
        emailField = findViewById(R.id.email1)
        passwordField = findViewById(R.id.Password1)
        logintaker()
        signiniup()

    }

    private fun logintaker()
    {
        logintext.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java) // Redirect to SignUp activity
            startActivity(intent)
        }
    }

    private fun signiniup()
    {
        auth = FirebaseAuth.getInstance()
        signUpButton.setOnClickListener {
            val email = emailField.text.toString()
            val password = passwordField.text.toString()

            auth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(this) { task ->
                    if (task.isSuccessful) {
                        // Sign up success, update UI with the signed-in user's information
                        Toast.makeText(this, "Sign Up Successful", Toast.LENGTH_SHORT).show()
                        finish()
                    } else {
                        // If sign up fails, display a message to the user.
                        Toast.makeText(this, "Sign Up Failed", Toast.LENGTH_SHORT).show()
                    }
                }

        }
    }
}