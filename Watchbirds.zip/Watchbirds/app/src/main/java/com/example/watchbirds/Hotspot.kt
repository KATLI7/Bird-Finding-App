package com.example.watchbirds

data class Hotspot(
    val locId: String,
    val locName: String,
    val lat: Double,
    val lng:Double
)
