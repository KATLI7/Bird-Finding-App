package com.example.watchbirds

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import com.example.watchbirds.R
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FieldValue

class Observations : AppCompatActivity() {

    private lateinit var birdNameEditText: EditText
    private lateinit var locationEditText: EditText
    private lateinit var addObservationButton: Button

    // Firestore instance
    private val db = FirebaseFirestore.getInstance()
    private val userId = FirebaseAuth.getInstance().currentUser?.uid // Get current logged-in user ID

    // Location services
    private lateinit var fusedLocationClient: FusedLocationProviderClient

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_observations)

        birdNameEditText = findViewById(R.id.editTextText3)
        locationEditText = findViewById(R.id.editTextText)
        addObservationButton = findViewById(R.id.button2)

        // Initialize FusedLocationProviderClient
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)

        addObservationButton.setOnClickListener {
            saveObservation()
        }
    }

    private fun saveObservation() {
        val birdName = birdNameEditText.text.toString()
        val location = locationEditText.text.toString()

        if (birdName.isNotEmpty() && location.isNotEmpty()) {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                // Request permissions if they are not granted
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 1)
                return
            }

            // Get the current location
            fusedLocationClient.lastLocation.addOnSuccessListener { locationResult ->
                if (locationResult != null) {
                    val latitude = locationResult.latitude
                    val longitude = locationResult.longitude

                    val observation = hashMapOf(
                        "birdName" to birdName,
                        "location" to location,
                        "latitude" to latitude,
                        "longitude" to longitude,
                        "timestamp" to FieldValue.serverTimestamp() // To track when the observation was added
                    )

                    userId?.let {
                        // Add observation to Firestore under the current user's ID
                        db.collection("users").document(it).collection("observations")
                            .add(observation)
                            .addOnSuccessListener {
                                Toast.makeText(this, "Observation added", Toast.LENGTH_SHORT).show()
                                birdNameEditText.text.clear()
                                locationEditText.text.clear()
                            }
                            .addOnFailureListener { e ->
                                Toast.makeText(this, "Failed to add observation: ${e.message}", Toast.LENGTH_LONG).show()
                            }
                    } ?: run {
                        Toast.makeText(this, "User not logged in", Toast.LENGTH_SHORT).show()
                    }

                } else {
                    Toast.makeText(this, "Could not retrieve location", Toast.LENGTH_SHORT).show()
                }
            }
        } else {
            Toast.makeText(this, "Please enter bird name and location", Toast.LENGTH_SHORT).show()
        }
    }
}
