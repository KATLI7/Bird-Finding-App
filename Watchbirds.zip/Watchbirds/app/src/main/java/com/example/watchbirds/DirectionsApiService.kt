import com.example.watchbirds.DirectionsResponse
import retrofit2.Response
import retrofit2.http.Query
import retrofit2.http.GET

interface DirectionsApiService {
    @GET("directions/json")
    suspend fun getDirections(
        @Query("origin") origin: String,
        @Query("destination") destination: String,
        @Query("key") apiKey: String
    ): Response<DirectionsResponse>
}
