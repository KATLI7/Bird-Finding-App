package com.example.watchbirds

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView

class settings : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        val imageView = findViewById<ImageView>(R.id.IconSetting2)
        val imageView3 = findViewById<ImageView>(R.id.imageView3)
        val imageView4 = findViewById<ImageView>(R.id.imageView4)

        imageView.setOnClickListener {
            // Create an Intent to navigate to MainActivity
            val intent = Intent(this, settings::class.java)
            startActivity(intent)


        }
        imageView3.setOnClickListener {
            val intent = Intent(this, Mapview::class.java)
            startActivity(intent)


        }
        imageView4.setOnClickListener {
            val intent = Intent(this, Collections::class.java)
            startActivity(intent)

        }

    }
}