package com.example.watchbirds


import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.Query



interface EbirdApiService {
    @GET("ref/hotspot/geo")
    fun getHotspots(
    @Header("X-eBirdApiToken") apiKey: String,   // API key in header
    @Query("lat") lat: Double,                   // Latitude as a query parameter
    @Query("lng") lng: Double,                   // Longitude as a query parameter
    @Query("dist") dist: Int,                    // Distance (in km) as a query parameter
    @Query("fmt") fmt: String = "json"           // Format (json)
): Call<List<Hotspot>>
}